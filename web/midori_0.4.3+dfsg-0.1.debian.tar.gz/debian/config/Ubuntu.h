#define DEBIAN_DISTRO_DEFAULT_HOMEPAGE "file:///usr/share/ubuntu-artwork/home/index.html"
#define DEBIAN_WWW_ALTERNATIVES_PRIORITY 39

